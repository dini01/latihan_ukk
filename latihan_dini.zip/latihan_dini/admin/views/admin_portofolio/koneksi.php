<?php 
$koneksi = mysqli_connect("localhost", "root", "", "portofolio_dini");
// if($koneksi) echo "<h1>KONEK";